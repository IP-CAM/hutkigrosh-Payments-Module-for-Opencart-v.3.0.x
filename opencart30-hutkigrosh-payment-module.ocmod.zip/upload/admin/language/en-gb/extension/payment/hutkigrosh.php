<?php

$_['heading_title'] = 'HutkiGrosh';

$_['text_hutkigrosh'] = '<img src="view/image/payment/hgrosh.png" alt="Hutkigrosh" title="Hutkigrosh" style="border: 1px solid #EEEEEE;" />';
$_['text_payment'] = 'Payment';
$_['text_success'] = 'Module settings have been updated!';


$_['text_test'] = 'Sandbox mode:';
$_['text_status'] = 'Status:';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_save'] = 'Save';
$_['text_cancel'] = 'Cancel';

$_['module_sort_order_label'] = 'Sort order';
$_['module_sort_order_description'] = '';
$_['module_status_label'] = 'Status';
$_['module_status_description'] = '';
$_['module_status_enable'] = 'Enable';
$_['module_status_disable'] = 'Disable';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the payment module!';