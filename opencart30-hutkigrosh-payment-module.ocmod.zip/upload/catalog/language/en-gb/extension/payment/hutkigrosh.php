<?php
// Text
$_['heading_title'] = 'Your order has been successfully added to ERIP! ';
$_['text_title'] = 'ERIP (Hutkigrosh)';

$_['text_home'] = 'Shop';
$_['text_basket'] = 'Shopping Cart';
$_['text_checkout'] = 'Checkout';
$_['text_success'] = 'Success';
$_['text_loading'] = 'Loading...';

$_['button_continue'] = 'Continue';

$_['text_sandbox'] = 'Payment Gateway in \'Sandbox \'. Funds from your account will not be removed.';
