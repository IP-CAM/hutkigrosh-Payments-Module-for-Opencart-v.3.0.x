<?php
/**
 * Created by IntelliJ IDEA.
 * User: nikit
 * Date: 06.12.2018
 * Time: 15:04
 */

namespace esas\hutkigrosh;


class Utils
{


}